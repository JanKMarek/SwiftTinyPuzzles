// Swift Tiny Puzzles

// Looping over strings. 

//   Refresher:
//   Swift supports UTF characters natively and these can have varying
//   number of bytes. As such, Swift arrays do not support accessing
//   individual characters by integers, it is necessary to use 
//   indexes instead.
//
//   Here is a chat sheet of oneliner methods for Swift 3

let str = "Hello world"
// str[4]:
str[str.index(str.startIndex, offsetBy: 4)]

// str[-2]: 
str[str.index(str.endIndex, offsetBy: -2)]

// str[2:5]
var q = str[str.index(str.startIndex, offsetBy: 2)...str.index(str.startIndex, offsetBy: 5)]

// str[:3]
var f = String(str.characters.prefix(3))
print(f)

// str[-3:]
var g = String(str.characters.suffix(3))
print(g)


// Puzzles - TBD
//
