// Swift Tiny Puzzles

// 4. Optionals and (forced) unwrapping

// Optionals arise when working with frameworks. 
//   When creating a variable, we need to make a decision:
//      a) never contains a nil - make it a regular type
//      b) may sometimes contain a nil - optional, check for nil and unwrap (or use optional binding)
//      c) will first be nil and then acquire value - IUO
//

// An optional is a variable which can contain a nil.
// Unlinke Obj-C, basic types can be optional as well, and non-optionals can NOT contain nil
// To declare an optional, use ? after type
// To access the value, use forced unwrapping !
// Forced unwrapping throws a runtime exception if nil is found, so you need to check for nil before unwrapping
// use optional binding to simplify the check+unwrap process

let inputString = "rrr"
var convertedNumber : Int? = Int(inputString)
if convertedNumber != nil {
    convertedNumber = convertedNumber! + 1
} else {
    print("not a number")
}

// use optional binding to simplify the check+unwrap process
// the optional is checked and unwrapped into a temporary variable or constant
var convNum = Int(inputString) // note convNum is Int?
if let num = Int(inputString) {
    print(num)
} else {
    print("incorrect input")
}

// Note that Int and Int? are different types, you need to unwrap
//   Int? before you can assign it to Int

// While the first two cases are very common, the third case is somewhat
// special, and occurs mostly in class initialization or when 
// we use frameworks. In these cases, we need to create a variable
// and leave it set to nil for a bit, and then we set the value
// and the value may change but is never nil afterwards.

// For these cases, we use implicitly unwrapped optionals. \
// An IUO is declared with an exclamation mark.
// Whenever accessed, it does not need the exclamation mark
// But if nil, still a runtime error - make sure you check
// IUOs should not be used when there is a chance of the 
//   variable containing a nil later - use optionals in this case. 
// IUOs means: get out of my way, swift, I know what I'm doing. No seat belt.
var iuo : String! // contains nil at this point
iuo = "value"
print(iuo) // do not need the exclamation mark to access
if (iuo != nil) {
    print(iuo)
} else {
    print("iuo has nil value")
}

// Optional chaining. 
//   Used for calls to properties, methods and subscripts on deeply nested
//   optional values: 
// if let buildingIdentifier = 
//          customer.residence?.address?[0].buildingIdentifier()?.description {
//               prinln(buidlingIdentifier);
// } else {
//    println("No address");
// }
//


//
// Remember the following:
//   after type: 
//      question mark - optional type declaration
//      exclamation mark - IUO type declaration
//   after variable: 
//      question mark - optional chaining
//      exclamation mark - forced unwrapping
//


















