
// Tiny puzzles for Swifts's for loops
//
// Swift provides two kinds of for loops: 
//   for-in loops
//   for condition increment loops


//1. for-in loops
//  if you only want to see values in arrays, dictionaries and strings:
let col = [1, 2, 3, 4, 5, 6]
var containsFour = false
for n in col {
    if (n == 4) {
        containsFour = true;
        break;
    }
}

var out = ""
for char in "The Game of Thrones".characters {
    if (char != " ") {
        out.append(char)
    }
}
print(out[3])
print(out)

// if you need access to indexes as well as values, you can do this:
var newcol : [Int] = []
for i in 0..<col.count {
    newcol.append(2 * col[i])
}



// 2. for-condition-increment loops

