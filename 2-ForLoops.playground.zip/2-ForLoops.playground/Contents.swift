// Swift Tiny Puzzles - For loops. 
//
// Quick refresher:
// Swift 3 only provides for-in loops, not C-style for loops. Here's how to use them:
//   1. for-in loops for cases when we only need the values:
var evenNumbers : [Int] = []
for k in [1, 2, 3, 4, 5] {
    if (k % 2 == 0) {
        evenNumbers.append(k)
    }
}

//   2. for-in loops for cases when we need indexes as well
let c = [1, 2, 3, 4, 5, 6, 3]
for i in 1..<c.count {
    if c[i-1] > c[i] {
        print("not in ascending order!")
    }
}

var out = ""
for char in "The Game of Thrones".characters {
    if (char != " ") {
        out.append(char)
    }
}


// Puzzle 1. 
//   Given an array of integers, create another array which contans even numbers from the original array multipled by two. Compare this to using the .map method.

// Puzzle 2. 
//   Find primes up to 1000 using the Sieve of Erasothenes method. Use array append remove.

// Puzzle 3.
//   Represent the Conway game of life board as an array of arrays. 
//   Populate the game of life board with data and print it to the console. 
//   Count how many squares are populated.

// Puzzle 4.
//   Create a function determining whether a particular square will live in the next step. Check Wikipedia for game rules.
//

// Puzzle 5.
//   Create a function which returs the entire board in the next step.
//

//--------------
//  Solutions:
//     TBD



