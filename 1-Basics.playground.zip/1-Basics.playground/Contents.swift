//
// Swift Tiny Puzzles - Basics
//


//    Swift is a strongly typed language, meaning each variable has a type
// (even though it may be inferred, not explicitly stated) and that type
// can not change during the execution of the program. 
//    Swift does not perform automatic conversions. 
//    Basic types for everyday work - integers, decimals, strings, booleans, dates and times, and collections of these types (arrays and dictionaries). 


// Puzzle 1.
//   Create an array of integers and populate it with some numbers. 
//   Determine how many times does number 4 occur in this array
//   and the index of the first occurence. 

// Puzzle 2. 
//   In your contact list, you have a set of names and birthdays. Given 
//   today's date, whose birthday comes up next and how many days is it 
//   from today? 

// Puzzle 3. 
//   Write a routine performing binary search over an array of floating 
//   point numbers. Return the index of the target number. 




